//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by SampleViewer.rc
//
#define IDD_FORMVIEW                    101
#define IDD_GRAPHVIEWER_DIALOG          103
#define IDR_SAMPLEVIEWER_TYPE           130
#define IDC_LIST1                       5000
#define IDD_PANEDIALOG                  5001
#define IDR_SAMPLEVIEWER_TOOLBAR        5002
#define IDR_SAMPLEVIEWER_BITMAP         5003
#define ID_SAMPLEVIEWER                 33100
#define ID_SAMPLEVIEWER_SHOWPANE        33101
#define ID_SAMPLEVIEWER_HIDEPANE        33102
#define ID_SAMPLEVIEWER_NEWVIEWER       33103
#define ID_BUTTON32775                  33104
#define ID_BUTTON32776                  33105
#define ID_BUTTON32777                  33106
#define ID_BUTTON32778                  33107
#define ID_SAMPLEVIEWER2_HERE           33108
#define ID_Menu                         33109
#define ID_SAMPLEVIEWER2_1              33110
#define ID_SAMPLEVIEWER2_2              33111
#define ID_SAMPLEVIEWER_ACTIVATEVERTICALPANE0 33112
#define ID_SAMPLEVIEWER_ACTIVATEHORIZONTALPANE3 33113

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        5005
#define _APS_NEXT_COMMAND_VALUE         32785
#define _APS_NEXT_CONTROL_VALUE         5001
#define _APS_NEXT_SYMED_VALUE           5002
#endif
#endif
