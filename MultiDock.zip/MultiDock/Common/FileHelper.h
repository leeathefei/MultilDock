/********************************************************************
	Created:	2015/04/27   11:20
	Filename:	FileHelper.h
	Author:		Chris Lee
	Functions:	
*********************************************************************/

class CFileHelper
{
public:
	static CString GetModuleDir();
};